NOTE:
99.9% of Armadillo source code is in the include folder,
in the form of heavily templated C++ code stored in header files.
