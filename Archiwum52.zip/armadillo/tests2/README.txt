- The tests in this directory are intended to be run only on Linux or macOS
- The tests are a work-in-progress
- Armadillo must be installed before the tests can be compiled
- To compile the tests, use "make"
- Run the tests by running the "main" executable
- NOTE: the tests are currently not suitable for compiling and running directly from CMake


Example:

make clean
make
./main

